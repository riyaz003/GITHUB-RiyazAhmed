let currentImageIndex = 0;

function nextImage() {
    const images = document.querySelectorAll('.hero img');
    const totalImages = images.length;

    // Remove the active class from the current image
    images[currentImageIndex].classList.remove('active');
    images[currentImageIndex].classList.add('inactive');

    // Update the index for the next image
    currentImageIndex = (currentImageIndex + 1) % totalImages;

    // Set the new image as active
    images[currentImageIndex].classList.remove('inactive');
    images[currentImageIndex].classList.add('active');
}
