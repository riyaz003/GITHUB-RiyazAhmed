const container = document.querySelector('.testimonial-container');

function scrollTestimonials(direction) {
  const scrollAmount = 320; // amount to scroll in pixels
  container.scrollBy({ left: direction * scrollAmount, behavior: 'smooth' });
}


const scrollTopBtn = document.getElementById('scrollTopBtn');

window.addEventListener('scroll', () => {
  if (window.scrollY > 200) {
    scrollTopBtn.style.display = 'block';
  } else {
    scrollTopBtn.style.display = 'none';
  }
});

scrollTopBtn.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

let currentSlide = 0;
const totalSlides = 3; // Total number of dot indicators

// Function to move to a specific slide
function moveToSlide(slideIndex) {
  currentSlide = slideIndex;
  
  // Move the testimonial container based on the currentSlide
  const testimonialContainer = document.querySelector('.testimonial-container');
  const cardWidth = document.querySelector('.testimonial-card').offsetWidth + 20; // Add gap width
  testimonialContainer.style.transform = `translateX(-${cardWidth * currentSlide}px)`;
  
  // Update active dot
  updateDots();
}

// Function to update the active dot
function updateDots() {
  const dots = document.querySelectorAll('.testimonial-dot');
  dots.forEach(dot => dot.classList.remove('active')); // Remove active class from all dots
  dots[currentSlide].classList.add('active'); // Add active class to the current dot
}

// Initialize the slider by moving to the first slide
moveToSlide(0);
